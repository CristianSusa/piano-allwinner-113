/* SPDX-License-Identifier: GPL-2.0+ */
/*
 *  Copyright (c) 2009 Ilya Yanok <yanok@emcraft.com>
 */

#ifndef ASM_ARCH_MXCMMC_H
#define ASM_ARCH_MXCMMC_H

int mxc_mmc_init(bd_t *bis);

#endif
